function dss_Capacitor_Data = get_capacitor(DSSCircuit)
    
    Capacitors = DSSCircuit.Capacitors;
    
    iC = Capacitors.First;
    
    if iC == 0
        dss_Capacitor_Data = {};
        return
    else
        names = Capacitors. AllNames;
    end

    n_cap = length(names);
    for i = 1 : n_cap
        Capacitors.Name = names{i}; % not assign value, but to set the "pointer" position
        dss_Capacitor_Data{i,1}.Name = Capacitors.Name;
        dss_Capacitor_Data{i,1}.kV = Capacitors.kV;
        dss_Capacitor_Data{i,1}.kvar = Capacitors.kvar;
        

        Capacitors.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_Capacitor_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_Capacitor_Data{i,1}.BusNames = act_ele.BusNames(1);   % act_ele.BusNames{2} is ground
        dss_Capacitor_Data{i,1}.n_cap = n_cap;
    end
    
end

