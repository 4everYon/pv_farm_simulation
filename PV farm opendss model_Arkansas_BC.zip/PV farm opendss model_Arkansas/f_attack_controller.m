% Identify Target Actor and Device

AffectedMeasurements = Scenario.AffectedMeasurement;

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Controller' 

                switch Scenario.AttackType{1}
                    case 'MITM'  
                       
                        switch Scenario.AttackModel{1}
                            case 'GradualChange'
                                if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 1) = 1;
                                    output(Targets, 2) = (1-3*rem(block.CurrentTime,10)/100) * ones(length(Targets),1);
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 3) = 1;
                                    output(Targets, 4) = 30*(rem(block.CurrentTime,10)/100) * ones(length(Targets),1);
                                end
            
                            case 'StepChange'
                                if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 1) = 1;
                                    output(Targets, 2) = 0.8 * ones(length(Targets),1);
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 3) = 1;
                                    output(Targets, 4) = 10 * ones(length(Targets),1);
                                end   
                                
                            case 'RandomChange'
                                if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 1) = 1;
                                    output(Targets, 2) = rand(1) * ones(length(Targets),1);
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    output(Targets, 3) = 1;
                                    output(Targets, 4) = 10*rand(1) * ones(length(Targets),1);
                                end      
                        
                        end
                end
                
                
        end
          
end

