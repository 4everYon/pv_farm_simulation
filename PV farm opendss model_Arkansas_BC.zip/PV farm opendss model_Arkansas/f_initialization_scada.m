SCADA_config.opendss_samplerate = 1;
SCADA_config.opendss_buffersize = 10;

SCADA_config.SCADA_samplerate = 1; 
SCADA_config.SCADA_buffersize = 10;

%% Place Holder, will use csv files later
PV_farm_bus = 'N_300033983'; %manually updated in OpenDSS file
read_file    = 'PL0001_January_osci.xlsx';
TS_data = readtable([pwd,'\xlsx_data\',read_file], 'Sheet', 'Time Series Data');

% locate the column representing PV_farm_bus
eval(['PV1 = TS_data.load_',PV_farm_bus,'_PV1;'])
eval(['PV2 = TS_data.load_',PV_farm_bus,'_PV2;'])
eval(['PV3 = TS_data.load_',PV_farm_bus,'_PV3;'])
Irridiance = (PV1 + PV2 + PV3)/max(PV1 + PV2 + PV3); 

eval(['P1 = TS_data.load_',PV_farm_bus,'_P1;'])
eval(['P2 = TS_data.load_',PV_farm_bus,'_P2;'])
eval(['P3 = TS_data.load_',PV_farm_bus,'_P3;'])
eval(['Q1 = TS_data.load_',PV_farm_bus,'_Q1;'])
eval(['Q2 = TS_data.load_',PV_farm_bus,'_Q2;'])
eval(['Q3 = TS_data.load_',PV_farm_bus,'_Q3;'])
Loading = (P1+P2+P3)/max(P1+P2+P3);

Temperature = xlsread([pwd,'\xlsx_data\','PL001_temper_low.xlsx']);



Irridiance = [Irridiance;Irridiance];
Temperature = [Temperature; Temperature];
Loading = [Loading;Loading];