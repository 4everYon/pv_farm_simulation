% Identify Target Actor and Device
AffectedMeasurements = Scenario.AffectedMeasurement;

PCC_idx = 1;

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Inverter' 
                
                switch Scenario.AttackType{1}
                        
                    case 'MITM'  
                        switch Scenario.AttackModel{1}
                            case 'GradualChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                
                            case 'StepChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * 0.8; 
                                end
                                
                            case 'RandomChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * rand(1); 
                                end
                                
                        end
                end
        end
        
        
    case 'SCADA'
        
        switch Scenario.TargetDevice{1}
            case 'Inverter' 
                
                switch Scenario.AttackType{1}
                        
                    case 'MITM'  
                        switch Scenario.AttackModel{1}
                            case 'GradualChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                
                            case 'StepChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * 0.8; 
                                end
                                
                            case 'RandomChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_I(Targets, :) = data_pv_I(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_pv_V(Targets, :) = data_pv_V(Targets, :) * rand(1); 
                                end
                                
                        end
                end
                
                
            case 'PCC'
                switch Scenario.AttackType{1}
                    
                    case 'MITM'
                        switch Scenario.AttackModel{1}
                            case 'GradualChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_I(PCC_idx, :) = data_tran_I(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100);
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_node_V(PCC_idx, :) = data_node_V(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                                end
                            case 'StepChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_I(PCC_idx, :) = data_tran_I(PCC_idx, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * 0.8; 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * 0.8;
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_node_V(PCC_idx, :) = data_node_V(PCC_idx, :) * 0.8; 
                                end
                            case 'RandomChange'
                                if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_I(PCC_idx, :) = data_tran_I(PCC_idx, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * rand(1); 
                                end
                                if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * rand(1);
                                end
                                if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                                    data_node_V(PCC_idx, :) = data_node_V(PCC_idx, :) * rand(1); 
                                end  
                                
                        end
                end
                
        end
    
        
end

