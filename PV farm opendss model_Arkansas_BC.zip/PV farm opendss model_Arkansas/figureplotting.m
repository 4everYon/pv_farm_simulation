%% figure plotting
close all
ind_bus = 2;
ind_phase = 1;
%% normal operation with t = 1440
% ind_pv1 = 1;% ind inverter
% ind_pv1p = 7;% real power phase
% ind_pv1v = 2;% voltage phase
% 
% ind_pv2 = 2;% ind inverter
% ind_pv2p = 7;% real power phase
% ind_pv2v = 2;% voltage phase
% 
% ind_pv3 = 3;% ind inverter
% ind_pv3p = 7;% real power phase
% ind_pv3v = 3;% voltage phase
% 
% vplot = simout.signals.values(ind_bus,ind_phase,:);
% vplot = reshape(vplot,size(vplot,3),1);
% 
% pvplot_temp = simout1.signals.values(ind_pv1,ind_pv1p,:);
% pvplot(:,1) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% pvplot_temp = simout1.signals.values(ind_pv1,ind_pv1v,:);
% pvplot(:,2) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% 
% pvplot_temp = simout1.signals.values(ind_pv2,ind_pv2p,:);
% pvplot(:,3) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% pvplot_temp = simout1.signals.values(ind_pv2,ind_pv2v,:);
% pvplot(:,4) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% 
% pvplot_temp = simout1.signals.values(ind_pv3,ind_pv3p,:);
% pvplot(:,5) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% pvplot_temp = simout1.signals.values(ind_pv3,ind_pv3v,:);
% pvplot(:,6) = reshape(pvplot_temp,size(pvplot_temp,3),1);



% t = 1/60:1/60:24;
% fs = 14;
% lw = 1.5;
% 
% figure
% hold on
% grid on
% plot(t,abs(vplot),'linewidth',lw)
% set(gca,'fontsize',fs)
% xlabel('Time (h)')
% ylabel('Voltage Magnitude (v)')
% 
% % figure
% % hold on
% % grid on
% % plot(t,rad2deg(angle(pvplot)),'linewidth',lw)
% % set(gca,'fontsize',fs)
% % xlabel('Time (h)')
% % ylabel('Phase Angle (rad)')
% 
% figure
% hold on
% grid on
% plot(t,abs(pvplot(:,1))/10,'linewidth',lw)
% % plot(t,abs(pvplot(:,3)),'linewidth',lw)
% % plot(t,abs(pvplot(:,5)),'linewidth',lw)
% set(gca,'fontsize',fs)
% xlabel('Time (h)')
% ylabel('Solar Irradiance (kW/m^2)')
% 
% figure
% hold on
% grid on
% plot(t,Temperature,'linewidth',lw)
% % plot(t,abs(pvplot(:,3)),'linewidth',lw)
% % plot(t,abs(pvplot(:,5)),'linewidth',lw)
% set(gca,'fontsize',fs)
% xlabel('Time (h)')
% ylabel('Temperature (\circ C)')
% 
% figure
% hold on
% grid on
% plot(t,abs(pvplot(:,1)),'linewidth',lw)
% % plot(t,abs(pvplot(:,3)),'linewidth',lw)
% % plot(t,abs(pvplot(:,5)),'linewidth',lw)
% set(gca,'fontsize',fs)
% xlabel('Time (h)')
% ylabel('PV Inverter Generation (kW)')
% 
% figure
% hold on
% grid on
% plot(t,abs(pvplot(:,2)),'linewidth',lw)
% plot(t,abs(pvplot(:,4)),'linewidth',lw)
% plot(t,abs(pvplot(:,6)),'linewidth',lw)
% set(gca,'fontsize',fs)
% xlabel('Time (h)')
% ylabel('Voltage Magnitude (V)')

%% attack detection
% ind_pv1 = 1;% ind inverter
% ind_pv1v = 1;% voltage phase
% 
% ind_pv2 = 2;% ind inverter
% ind_pv2v = 2;% voltage phase
% 
% ind_pv3 = 3;% ind inverter
% ind_pv3v = 3;% voltage phase
% 
% pvplot_temp = simout4.signals.values(ind_pv1,ind_pv1v,:);
% pvplot(:,1) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% 
% pvplot_temp = simout4.signals.values(ind_pv2,ind_pv2v,:);
% pvplot(:,2) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% 
% pvplot_temp = simout4.signals.values(ind_pv3,ind_pv3v,:);
% pvplot(:,3) = reshape(pvplot_temp,size(pvplot_temp,3),1);
% 
% t = 1/60:1/60:900*1/60+1/60;
fs = 14;
lw = 1.5;

figure
subplot(2,1,1)
hold on
grid on
plot(simout2.time,simout2.signals.values,'r','linewidth',lw)
xlabel('Time (h)')
ylabel('Attack Signal')
set(gca,'fontsize',fs)

% subplot(3,1,2)
% hold on
% grid on
% plot(t,abs(pvplot(:,1)),'linewidth',lw)
% plot(t,abs(pvplot(:,2)),'linewidth',lw)
% plot(t,abs(pvplot(:,3)),'linewidth',lw)
% xlabel('Time (h)')
% ylabel('Voltage Magnitude (V)')

subplot(2,1,2)
hold on
grid on
plot(simout3.time,simout3.signals.values,'b','linewidth',lw)
xlabel('Time (h)')
ylabel('Detection Signal')
set(gca,'fontsize',fs)

detection_error = simout3.signals.values - simout2.signals.values;
positive_data = simout3.signals.values(find(simout2.signals.values == 1));
negative_data = simout3.signals.values(find(simout2.signals.values == 0));
length(find(positive_data == 1))/length(positive_data)% true positive
length(find(positive_data == 0))/length(positive_data)% fake negative
length(find(negative_data == 1))/length(negative_data)% fake positive
length(find(negative_data == 0))/length(negative_data)% true negative
