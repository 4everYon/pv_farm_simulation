clc
clear

Scenarios = readtable([ pwd , '\xlsx_data\attack_data_batch.xlsx' ]); 

%% Run Simulink Model in batch mode
n_scenarios = size(Scenarios, 1);
for scenario_idx = 1 : n_scenarios
    
    if scenario_idx>=25
    
        sub_folder_name = ['scenario', char(string(scenario_idx))];            
        NumberOfScenariosToRun = Scenarios(scenario_idx,:).NumberOfScenariosToRun;
        for exp_idx = 1 : NumberOfScenariosToRun
            cd C:\Users\bo.chen\Desktop\Sim_DSS
            delete batch_para.mat
            save('batch_para.mat', 'Scenarios', 'scenario_idx', 'exp_idx','sub_folder_name');
            mkdir('sim_data', sub_folder_name)
            disp( sprintf('Running Scenario %d, Experiment %d', scenario_idx, exp_idx) );

            batch_mode = 1;
            sim('Simulink_OpenDSS'); % cannot bebug simulink model by calling this

%             cd C:\Users\bo.chen\Desktop\Sim_DSS
%             load('batch_para.mat');
%             disp( sprintf('Saving Scenario %d, Experiment %d', scenario_idx, exp_idx) );
%     %         Filename = [char(strrep(string(datestr(now,'HH:MM:SS')), ':', '-')), '-scenario', char(string(scenario_idx)),'-experiment', char(string(exp_idx))];
%             Filename = ['scenario', char(string(scenario_idx)),'-experiment', char(string(exp_idx))];
%             save([pwd, '\sim_data\', sub_folder_name,'\' Filename], 'Voltage_data', 'Line_data', 'Transformer_data', 'Load_data', 'Capacitor_data');
        end
    
    end

end

%% Post-simulation data processing
