function dss_Line_Data = f_get_line(DSSCircuit)

    Lines = DSSCircuit.Lines;
    
    iL = Lines.First;
    
    if iL == 0
        dss_Line_Data = {};
        return
    else
        names = Lines.AllNames;
    end
    
    n_line = length(names);
    for i = 1 : n_line
        Lines.Name = names{i}; % not assign value, but to set the "pointer" position
%         dss_Line_Data{i,1} = Lines.get; %%%%%%%%%%%%%%%%%%%%%%  Lines.get may have a problem
        dss_Line_Data{i,1}.Name = Lines.Name;
        dss_Line_Data{i,1}.Bus1 = Lines.Bus1;
        dss_Line_Data{i,1}.Bus2 = Lines.Bus2;
        dss_Line_Data{i,1}.LineCode = Lines.LineCode;
        dss_Line_Data{i,1}.Phases = Lines.Phases;
        dss_Line_Data{i,1}.R1 = Lines.R1;
        dss_Line_Data{i,1}.X1 = Lines.X1;
        dss_Line_Data{i,1}.R0 = Lines.R0;
        dss_Line_Data{i,1}.X0 = Lines.X0;
        dss_Line_Data{i,1}.C1 = Lines.C1;
        dss_Line_Data{i,1}.C0 = Lines.C0;
        dss_Line_Data{i,1}.NormAmps = Lines.NormAmps;
        dss_Line_Data{i,1}.EmergAmps = Lines.EmergAmps;
        dss_Line_Data{i,1}.Count = Lines.Count;
        
        dss_Line_Data{i,1}.Length = Lines.Length;
        dss_Line_Data{i,1}.Units = Lines.Units; % Units= {1:mi, 2:km, 3:kft, 4:m, 5:ft, 6:in, 7:cm}
        
      
        
        
        if not( isempty(Lines.LineCode) )
            dss_Line_Data{i,1}.Rmatrix = Lines.Rmatrix * dss_Line_Data{i,1}.Length; % comes in ohm per unit(1 to 5)
            dss_Line_Data{i,1}.Xmatrix = Lines.Xmatrix * dss_Line_Data{i,1}.Length;
            dss_Line_Data{i,1}.Cmatrix = Lines.Cmatrix * dss_Line_Data{i,1}.Length;
        end
        if not( isempty(Lines.Geometry) )% when geometry is available, then the length is already considered.
            dss_Line_Data{i,1}.Rmatrix = Lines.Rmatrix; 
            dss_Line_Data{i,1}.Xmatrix = Lines.Xmatrix;
            dss_Line_Data{i,1}.Cmatrix = Lines.Cmatrix;
        end
        if isempty(Lines.LineCode) && isempty(Lines.Geometry) % some lines called "other feeders"
            dss_Line_Data{i,1}.Rmatrix = Lines.Rmatrix; 
            dss_Line_Data{i,1}.Xmatrix = Lines.Xmatrix;
            dss_Line_Data{i,1}.Cmatrix = Lines.Cmatrix;
        end
        
        
        Lines.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_Line_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_Line_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_Line_Data{i,1}.n_line = n_line;
    end
    

end

