function dss_CapControl_Data = get_capcontrol(DSSCircuit)
    
    Capcontrols = DSSCircuit.CapControls;
    
    iCap = Capcontrols.Count;
    
    if iCap == 0
        dss_CapControl_Data = {};
        return
    else
        names = Capcontrols.AllNames; % will go through all capacitors
    end

    n_capcontrol = length(names);
    for i = 1 : n_capcontrol
        Capcontrols.Name = names{i}; % not assign value, but to set the "pointer" position

        dss_CapControl_Data{i,1}.Name = Capcontrols.Name;
        dss_CapControl_Data{i,1}.Capacitor = Capcontrols.Capacitor;
        dss_CapControl_Data{i,1}.Count = Capcontrols.Count;    
        dss_CapControl_Data{i,1}.CTratio = Capcontrols.CTratio;
        dss_CapControl_Data{i,1}.DeadTime = Capcontrols.DeadTime;
        dss_CapControl_Data{i,1}.Delay = Capcontrols.Delay;
        dss_CapControl_Data{i,1}.DelayOff = Capcontrols.DelayOff;
        dss_CapControl_Data{i,1}.Mode = Capcontrols.Mode;
        dss_CapControl_Data{i,1}.MonitoredObj = Capcontrols.MonitoredObj;
        dss_CapControl_Data{i,1}.MonitoredTerm = Capcontrols.MonitoredTerm;
        dss_CapControl_Data{i,1}.OFFSetting = Capcontrols.OFFSetting;
        dss_CapControl_Data{i,1}.ONSetting = Capcontrols.ONSetting;
        dss_CapControl_Data{i,1}.PTratio = Capcontrols.PTratio;
        dss_CapControl_Data{i,1}.UseVoltOverride = Capcontrols.UseVoltOverride;
        dss_CapControl_Data{i,1}.Vmax = Capcontrols.Vmax;
        dss_CapControl_Data{i,1}.Vmin = Capcontrols.Vmin;
        
        
        Capcontrols.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_CapControl_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_CapControl_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_CapControl_Data{i,1}.n_capcontrol = n_capcontrol;
    end
    
    
end

