n_time = length(simout2.time);

false_negtive = 0;
false_positive = 0;
true_negtive = 0;
true_positive = 0;

for i = 1 : n_time
    if simout2.signals.values(i) == 1 && simout3.signals.values(i) == 1
        true_positive = true_positive + 1;
    end
    
    if simout2.signals.values(i) == 0 && simout3.signals.values(i) == 0
        true_negtive = true_negtive + 1;
    end
    
    if simout2.signals.values(i) == 1 && simout3.signals.values(i) == 0
        false_negtive = false_negtive + 1;
    end
    
    if simout2.signals.values(i) == 0 && simout3.signals.values(i) == 1
        false_positive = false_positive + 1;
    end
    
    
end


disp(['false_negtive  ', num2str(false_negtive/(false_negtive + true_negtive)*100),'%']);
 
disp(['false_positive  ', num2str(false_positive/(false_positive + true_positive)*100),'%']);

disp(['true_negtive  ', num2str(true_negtive/(false_negtive + true_negtive)*100),'%']);

disp(['true_positive  ', num2str(true_positive/(false_positive + true_positive)*100),'%']);