


Current_irridiance = Irridiance(ceil(time + 0.1));
Current_true_Q = 1 * Current_irridiance;

[DSSStartOK, DSSObj, DSSText] = DSSStartup;
DSSCircuit = DSSObj.ActiveCircuit;
DSSSolution = DSSCircuit.Solution;
    for ii = 1 : System_config.PV{1,1}.n_pv
        DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.kvar=', num2str(Current_true_Q)];%% original value is 0
    end
DSSSolution.Solve()

%% find PV inverter observer values
    out_PVVIPQ = [];
    PVNames = DSSCircuit.PVSystems.AllNames;
    for i = 1 : DSSCircuit.PVSystems.Count
        DSSCircuit.SetActiveElement(['PVSystem.', PVNames{i}]); %%%%%%%%%%%%%
        DSSCircuit.PVSystems.Name = PVNames{i}; %%%%%%%%%%%%%
        three_phase_value = f_phase_alignment(DSSCircuit,'pv');
        out_PVVIPQ = [out_PVVIPQ; three_phase_value];    
    end
%% find substation observer values
    out_SUBV = [];
    out_SUBIPQ = [];
    BusNames = DSSCircuit.AllBusNames;
    %% remove duplicate buses
    [UniqueBus IA IC] = unique(BusNames,'first');
    indexToDupes = find(not(ismember(1:numel(BusNames),IA)));
    BusNames(indexToDupes) = [];
    %% Sub voltage
    DSSCircuit.SetActiveBus(BusNames{1});
    three_phase_value = f_phase_alignment(DSSCircuit,'bus');
    out_SUBV = [out_SUBV; three_phase_value];  
    %% transformer current
    TranNames = DSSCircuit.Transformers.AllNames;
    for i = 1 : DSSCircuit.Transformers.Count
        DSSCircuit.SetActiveElement(['Transformer.', TranNames{i}]); %%%%%%%%%%%%%%
        DSSCircuit.Transformers.Name = TranNames{i}; %%%%%%%%%%%%%
        three_phase_value = f_phase_alignment(DSSCircuit, 'transformer');
        out_SUBIPQ = [out_SUBIPQ; three_phase_value];    
    end   

detection_status = 0;
for i = 1 : n_pv
    
    threshold = 0.05;
    % V
    mismatch = max(abs(out_PVVIPQ(i, 1:3) - data_pv_V(i,:)));
    if mismatch > threshold
        detection_status = 1;
    end
    % I
    mismatch = max(abs(out_PVVIPQ(i, 4:6) - data_pv_I(i,:)));
    if mismatch > threshold
        detection_status = 1;
    end
    
    threshold = 0.01;
    % PQ
    mismatch = max(abs(out_PVVIPQ(i, 7:9) - data_pv_PQ(i,:))./abs(out_PVVIPQ(i, 7:9) + 0.01));  % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end
    % PF
    mismatch = max(abs(out_PVVIPQ(i, 7:9) - data_pv_PQ(i,:))./abs(out_PVVIPQ(i, 7:9) + 0.0001));  % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end    
end
    % PCC V
    mismatch = max(abs(out_SUBV(1, 1:3) - data_node_V(1,:)));  % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end   
    
    % PCC I
    mismatch = max(abs(out_SUBIPQ(1, 1:6) - data_tran_I(1,1:6)));  % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end  
     
    % PCC PQ
    mismatch = max(abs(out_SUBIPQ(1, 7:12) - data_tran_PQ(1,1:6))); % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end  
    
    if time>=450
        mismatch = max(abs(out_PVVIPQ(i, 7:9) - data_pv_PQ(i,:))./abs(out_PVVIPQ(i, 7:9) + 0.0001));
    end

% for i = 1 : n_pv
%     PV_PQ = sum(data_pv_PQ(i, 7:9));
%     PV_PQ_theory = Current_irridiance * System_config.PV{i}.kVArated * System_config.PV{i}.
%     threshold = 0.1;
% %     if PV_PQ - 
%     
% end