function Sim_Attack_Gen(block)
    setup(block);

function setup(block)

    % Register the number of ports.
    block.NumInputPorts  = 0;
    block.NumOutputPorts = 2;

    % Set up the port properties to be inherited or dynamic.
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;
    
    block.OutputPort(1).Dimensions     = 1;
    block.OutputPort(1).Complexity     = 'real';
    block.OutputPort(1).SamplingMode   = 'Sample';
    
    block.OutputPort(2).Dimensions     = 1;
    block.OutputPort(2).Complexity     = 'real'; 
    block.OutputPort(2).SamplingMode   = 'Sample';
   
    
    % Register the parameters.
    block.NumDialogPrms     = 4;

    block.SampleTimes = [-1 0];
    block.SetAccelRunOnTLC(false);
    block.SimStateCompliance = 'DefaultSimState';

    block.RegBlockMethod('SetInputPortSamplingMode', @SetInpPortFrameData);
    block.RegBlockMethod('Outputs', @Outputs);
 
function SetInpPortFrameData(block, idx, fd)
    block.InputPort(idx).SamplingMode = fd;
    block.OutputPort(idx).SamplingMode = fd;

function SetInputDimsMode(block, port, dm)
    block.InputPort(port).DimensionsMode = dm;
    block.OutputPort(port).DimensionsMode = dm;

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Outputs(block)
    System_config = block.DialogPrm(2).Data;
    SCADA_config    = block.DialogPrm(3).Data;
    Attack_config = block.DialogPrm(4).Data;
        
   
    StartTime = Attack_config.Scenarios.StartTime;
    EndTime = Attack_config.Scenarios.EndTime;
    
    
    for i = 1 : length(StartTime)
        if block.CurrentTime >= StartTime(i) && block.CurrentTime < EndTime(i)
            if strcmp(Attack_config.Scenarios.TargetActor(i), 'Fault')
                attack_status = 0;
            else
                attack_status = 1;
            end
            Scenario_idx = i;
            break;
        else
            attack_status = 0;
            Scenario_idx = 0;
        end
    end
   

    block.OutputPort(1).Data = Scenario_idx;
    block.OutputPort(2).Data = attack_status ;
        

  
    
  
