% Identify Target Actor and Device
AffectedMeasurements = Scenario.AffectedMeasurement;

PCC_idx = 1;

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Inverter' 
                
                switch Scenario.AttackType{1}
                    case 'DoS'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(Targets, :) = data_pv_I(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(Targets, :) = data_pv_V(Targets, :) * NaN;
                        end
                        
                    case 'MITM'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(Targets, :) = data_pv_I(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(Targets, :) = data_pv_V(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                end
        end
        
        
    case 'SCADA'
        
        switch Scenario.TargetDevice{1}
            case 'Inverter' 
                
                switch Scenario.AttackType{1}
                    case 'DoS'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(Targets, :) = data_pv_I(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(Targets, :) = data_pv_V(Targets, :) * NaN;
                        end
                        
                    case 'MITM'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(Targets, :) = data_pv_I(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(Targets, :) = data_pv_PQ(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(Targets, :) = data_pv_V(Targets, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                end
                
                
            case 'PCC'
                switch Scenario.AttackType{1}
                    
                    case 'MITM'
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_tran_I(PCC_idx, :) = data_tran_I(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'P') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_tran_PQ(PCC_idx, :) = data_tran_PQ(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100);
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_node_V(PCC_idx, :) = data_node_V(PCC_idx, :) * (1-rem(block.CurrentTime,10)/100); 
                        end
                    
                end
                
        end
    
        
end

