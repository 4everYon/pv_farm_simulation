function Sim_DSS(block)
setup(block);
  
function setup(block)
    % Register the number of ports.
    block.NumInputPorts  = 4;
    block.NumOutputPorts = 6;   % Voltage, Current, Power

    % Set up the port properties to be inherited or dynamic.
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;

    
    % Register the properties of the output port
    DSS_port_config = block.DialogPrm(1).Data;
    System_config = block.DialogPrm(2).Data;
    SCADA_config = block.DialogPrm(3).Data;
   
    
    block.InputPort(1).DimensionsMode = 'Fixed'; %%% Irridiance
    block.InputPort(1).Dimensions     = 1440;
    block.InputPort(1).DataTypeId     = 0;
    block.InputPort(1).Complexity     = 'real';
    block.InputPort(1).SamplingMode   = 'Sample';

    block.InputPort(2).DimensionsMode = 'Fixed'; %%% Temperature
    block.InputPort(2).Dimensions     = 1440;
    block.InputPort(2).DataTypeId     = 0;
    block.InputPort(2).Complexity     = 'real';
    block.InputPort(2).SamplingMode   = 'Sample';

    block.InputPort(3).DimensionsMode = 'Fixed';  %%% Loading Factor
    block.InputPort(3).Dimensions     = 1440;
    block.InputPort(3).DataTypeId     = 0;
    block.InputPort(3).Complexity     = 'real';
    block.InputPort(3).SamplingMode   = 'Sample';
    
    n_pv = System_config.PV{1,1}.n_pv;
    block.InputPort(4).DimensionsMode = 'Fixed';  %%% Attack Parameter if PV control command is attacked
    block.InputPort(4).Dimensions     = [n_pv 4]; %%% [flag_PF, PF, flag_kvar, kvar]
    block.InputPort(4).DataTypeId     = 0;
    block.InputPort(4).Complexity     = 'real';
    block.InputPort(4).SamplingMode   = 'Sample';
    

    % Register the properties of the output port
    block.OutputPort(1).DimensionsMode = 'Fixed';
    block.OutputPort(1).Dimensions     = DSS_port_config.port1dim;
    block.OutputPort(1).DataTypeId     = 0;
    block.OutputPort(1).Complexity     = 'complex';
    block.OutputPort(1).SamplingMode   = 'Sample';

    block.OutputPort(2).DimensionsMode = 'Fixed';
    block.OutputPort(2).Dimensions     = DSS_port_config.port2dim;
    block.OutputPort(2).DataTypeId     = 0;
    block.OutputPort(2).Complexity     = 'complex';
    block.OutputPort(2).SamplingMode   = 'Sample';
    
    block.OutputPort(3).DimensionsMode = 'Fixed';
    block.OutputPort(3).Dimensions     = DSS_port_config.port3dim;
    block.OutputPort(3).DataTypeId     = 0;
    block.OutputPort(3).Complexity     = 'complex';
    block.OutputPort(3).SamplingMode   = 'Sample';
    
    block.OutputPort(4).DimensionsMode = 'Fixed';
    block.OutputPort(4).Dimensions     = DSS_port_config.port4dim;
    block.OutputPort(4).DataTypeId     = 0;
    block.OutputPort(4).Complexity     = 'complex';
    block.OutputPort(4).SamplingMode   = 'Sample';  
    
    block.OutputPort(5).DimensionsMode = 'Fixed';
    block.OutputPort(5).Dimensions     = DSS_port_config.port5dim;
    block.OutputPort(5).DataTypeId     = 0;
    block.OutputPort(5).Complexity     = 'complex';
    block.OutputPort(5).SamplingMode   = 'Sample';    
   
    block.OutputPort(6).DimensionsMode = 'Fixed';
    block.OutputPort(6).Dimensions     = DSS_port_config.port6dim;
    block.OutputPort(6).DataTypeId     = 0;
    block.OutputPort(6).Complexity     = 'complex';
    block.OutputPort(6).SamplingMode   = 'Sample';   
    
    
    block.NumDialogPrms = 3;  % block.DialogPrm(1) is DSS_port_config used to specify system_folder_path and master_dss_file
    block.SampleTimes = [SCADA_config.opendss_samplerate 0]; % block.DialogPrm(2) is DMS_config
    block.SetAccelRunOnTLC(false);
    block.SimStateCompliance = 'DefaultSimState';
    
    block.RegBlockMethod('Outputs', @Outputs);

  
function Outputs(block)
    %%
    DSS_port_config = block.DialogPrm(1).Data;
    System_config = block.DialogPrm(2).Data;
    SCADA_config = block.DialogPrm(3).Data;
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Irridiance = block.InputPort(1).Data;
%     Irridiance = rand(1440);
    Irridiance = 0.4*ones(1440,1);
    
%     Temperature = block.InputPort(2).Data;
    Temperature = 10*ones(1440,1);
    
%     Loading = block.InputPort(3).Data;
    Loading = 0.6*ones(1440,1);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Attack_control = block.InputPort(4).Data;
    
    time = block.CurrentTime;
    
    % it seems like DSSStartup can remember the system path and master file name after initialization
    [DSSStartOK, DSSObj, DSSText] = DSSStartup;
    DSSCircuit = DSSObj.ActiveCircuit;
    DSSSolution = DSSCircuit.Solution;
    
    
    %% Update Irridiance and Temperature
    for ii = 1 : System_config.PV{1,1}.n_pv
        DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.irrad=', num2str(Irridiance(ceil(time+0.1)))];
%         DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.irrad=', num2str(0.5+rand())];
        DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.temperature=', num2str(Temperature(ceil(time+0.1)))];
%         DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.temperature=', num2str(25)];
        
        %% Implement Controller Attack
        if round(Attack_control(ii,1)) == 1
            DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.PF=', num2str(Attack_control(ii,2))];
        end
        if round(Attack_control(ii,3)) == 1
            DSSText.command = ['PVSystem.', System_config.PV{ii,1}.Name,'.kvar=', num2str(Attack_control(ii,4))];%% original value is 0
        end
    end
    
    DSSText.command = ['Set Loadmult=', num2str(Loading(ceil(time+0.1)))];
    
    
    DSSSolution.Solve()
    
    
    %%  Fault Implementation
    if time == 0
        DSSText.command = ['New Fault.F1 phases=1 Bus1=Farm_.1 R=0.002'];
        DSSText.command = ['New Fault.F2 phases=3 Bus1=Farm_ R=0.002'];
    end
    
    if 1<=time && time<9 
        DSSText.Command= ['Fault.F1.enabled=yes'];
        DSSSolution.Solve()
    else
        DSSText.Command= ['Fault.F1.enabled=no'];
        DSSSolution.Solve()
    end
    
    if 11<=time && time<19
        DSSText.Command= ['Fault.F2.enabled=yes'];
        DSSSolution.Solve()
    else
        DSSText.Command= ['Fault.F2.enabled=no'];
        DSSSolution.Solve()
    end
    
    
    
    %% check results
%     DSSText.Command ='Show currents';
%     DSSText.Command ='Show Powers';
%     DSSText.Command ='Show Voltages';



        
    %%
    % output bus voltage magnitude and angle as a complex matrix
    out_VMagAngle = [];
    BusNames = DSSCircuit.AllBusNames;
    for i = 1 : DSSCircuit.NumBuses
        DSSCircuit.SetActiveBus(BusNames{i});
        three_phase_value = f_phase_alignment(DSSCircuit,'bus');
        out_VMagAngle = [out_VMagAngle; three_phase_value];    
    end
        
    % output line two-way current and active and reactive power as a complex matrix
    out_LineCMagAngleandPQ = [];
    LineNames = DSSCircuit.Lines.AllNames;
    for i = 1 : DSSCircuit.Lines.Count
        DSSCircuit.SetActiveElement(['Line.', LineNames{i}]); %%%%%%%%%%%%%%
        three_phase_value = f_phase_alignment(DSSCircuit, 'line');
        out_LineCMagAngleandPQ = [out_LineCMagAngleandPQ; three_phase_value];    
    end
    
    % output transformer two-way current and active and reactive power as a complex matrix
    out_TranCMagAngleandPQ = [];
    TranNames = DSSCircuit.Transformers.AllNames;
    for i = 1 : DSSCircuit.Transformers.Count
        DSSCircuit.SetActiveElement(['Transformer.', TranNames{i}]); %%%%%%%%%%%%%%
        DSSCircuit.Transformers.Name = TranNames{i}; %%%%%%%%%%%%%
        three_phase_value = f_phase_alignment(DSSCircuit, 'transformer');
        out_TranCMagAngleandPQ = [out_TranCMagAngleandPQ; three_phase_value];    
    end
    
    % output Load current and power
    out_LoadCMagAngleandPQ = [];
    if strcmp(System_config.Load{1,1}.Name, 'Fake_Load')
        out_LoadCMagAngleandPQ = zeros(1,DSS_port_config.port4dim(2));
    else
        LoadNames = DSSCircuit.Loads.AllNames;
        for i = 1 : DSSCircuit.Loads.Count
            DSSCircuit.SetActiveElement(['Load.', LoadNames{i}]);
            three_phase_value = f_phase_alignment(DSSCircuit,'load');
            out_LoadCMagAngleandPQ = [out_LoadCMagAngleandPQ; three_phase_value];    
        end
    end
    
    % output capacitor current and power
    out_CapCMagAngleandPQ = [];
    if strcmp(System_config.Cap{1,1}.Name, 'Fake_Cap')
        out_CapCMagAngleandPQ = zeros(1,DSS_port_config.port5dim(2));
    else
        CapNames = DSSCircuit.Capacitors.AllNames;
        for i = 1 : DSSCircuit.Capacitors.Count
            DSSCircuit.SetActiveElement(['Capacitor.', CapNames{i}]); %%%%%%%%%%%%%
            DSSCircuit.Capacitors.Name = CapNames{i}; %%%%%%%%%%%%%
            three_phase_value = f_phase_alignment(DSSCircuit,'capacitor');
            out_CapCMagAngleandPQ = [out_CapCMagAngleandPQ; three_phase_value];    
        end
    end
    
    
    out_PVVIPQ = [];
    PVNames = DSSCircuit.PVSystems.AllNames;
    for i = 1 : DSSCircuit.PVSystems.Count
        DSSCircuit.SetActiveElement(['PVSystem.', PVNames{i}]); %%%%%%%%%%%%%
        DSSCircuit.PVSystems.Name = PVNames{i}; %%%%%%%%%%%%%
        three_phase_value = f_phase_alignment(DSSCircuit,'pv');
        out_PVVIPQ = [out_PVVIPQ; three_phase_value];    
    end
    
    
    %%
    block.OutputPort(1).Data = out_VMagAngle;
    block.OutputPort(2).Data = out_LineCMagAngleandPQ;
    block.OutputPort(3).Data = out_TranCMagAngleandPQ;
    block.OutputPort(4).Data = out_LoadCMagAngleandPQ;
    block.OutputPort(5).Data = out_CapCMagAngleandPQ;
    block.OutputPort(6).Data = out_PVVIPQ;
    