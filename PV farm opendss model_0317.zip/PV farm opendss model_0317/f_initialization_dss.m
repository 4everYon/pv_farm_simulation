system_folder_path = 'C:\test\PVfarm';
master_dss_file    = 'Master.dss';


% execute DSSStartup.m
[DSSStartOK, DSSObj, DSSText] = DSSStartup;

% get system configuration data from OpenDSS COM
if DSSStartOK

    DSSText.command = ['cd ', system_folder_path];
    DSSText.command = ['compile ', '(', master_dss_file, ')'];
    DSSCircuit = DSSObj.ActiveCircuit;
    DSSSolution = DSSCircuit.Solution;

    dss_Bus_Data = f_get_bus(DSSCircuit);
    dss_Load_Data = f_get_load(DSSCircuit);
    dss_Transformer_Data = f_get_transformer(DSSCircuit);
    dss_Line_Data = f_get_line(DSSCircuit);
    dss_Capacitor_Data = f_get_capacitor(DSSCircuit);   
    dss_CapControl_Data = f_get_capcontrol(DSSCircuit);  
    dss_RegControl_Data = f_get_regcontrol(DSSCircuit);
    dss_PVSystems_Data = f_get_pv(DSSCircuit);

    % tranlate to models used for Simulink
    System_config.Bus       = dss_Bus_Data;
    System_config.Line      = dss_Line_Data;
    System_config.Trans     = dss_Transformer_Data;        
    System_config.Load      = dss_Load_Data;        
    System_config.Cap       = dss_Capacitor_Data;
    System_config.CapCtrl   = dss_CapControl_Data;
    System_config.RegCtrl   = dss_RegControl_Data;
    System_config.PV        = dss_PVSystems_Data;

    n_node  = length(System_config.Bus);
    n_line  = length(System_config.Line);
    n_trans = length(System_config.Trans);
    n_load  = length(System_config.Load);
    n_cap   = length(System_config.Cap);
    n_pv    = length(System_config.PV);
    
    if n_load == 0
        n_load = 1;
        System_config.Load{1,1}.Name = 'Fake_Load';
        System_config.Load{1,1}.kV = 0;
        System_config.Load{1,1}.kW = 0;
        System_config.Load{1,1}.kvar = 0;
        System_config.Load{1,1}.NumPhases = 3;
        System_config.Load{1,1}.BusNames = System_config.Bus{1,1}.Name;   
        System_config.Load{1,1}.n_load = 1;
    end
    
    if n_cap == 0
        n_cap = 1;
        System_config.Cap{1,1}.Name = 'Fake_Cap';
        System_config.Cap{1,1}.kV = 0;
        System_config.Cap{1,1}.kW = 0;
        System_config.Cap{1,1}.kvar = 0;
        System_config.Cap{1,1}.NumPhases = 3;
        System_config.Cap{1,1}.BusNames = System_config.Bus{1,1}.Name;   
        System_config.Cap{1,1}.n_cap = 1;
    end
    
    DSS_port_config.port1dim = [n_node, 3];
    DSS_port_config.port2dim = [n_line, 12]; 
    DSS_port_config.port3dim = [n_trans,13];
    DSS_port_config.port4dim = [n_load, 6];
    DSS_port_config.port5dim = [n_cap, 7];
    DSS_port_config.port6dim = [n_pv, 9];
    

%%
    clearvars -except 'DSS_port_config'  'System_config' 'Attack_config' 'batch_mode'

else 
    message('Oops! DSS Did Not Start..')
end