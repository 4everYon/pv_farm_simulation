function dss_RegControl_Data = get_regcontrol(DSSCircuit)
    
    Regcontrols = DSSCircuit.RegControls;
    
    iRg = Regcontrols.First;
    
    if iRg == 0
        dss_RegControl_Data = {};
        return
    else
        names = Regcontrols.AllNames; % will go through all transformers
    end

    n_regcontrol = length(names);
    for i = 1 : n_regcontrol
        Regcontrols.Name = names{i}; % not assign value, but to set the "pointer" position
%         dss_RegControl_Data{i,1} = Regcontrols.get;  % Regcontrols.get
%         has a bug
        dss_RegControl_Data{i,1}.Name = Regcontrols.Name;
        dss_RegControl_Data{i,1}.Transformer = Regcontrols.Transformer;
        dss_RegControl_Data{i,1}.TapWinding = Regcontrols.TapWinding;
        dss_RegControl_Data{i,1}.Winding = Regcontrols.Winding;
        dss_RegControl_Data{i,1}.CTPrimary = Regcontrols.CTPrimary;
        dss_RegControl_Data{i,1}.PTratio = Regcontrols.PTratio;
        dss_RegControl_Data{i,1}.ForwardR = Regcontrols.ForwardR;
        dss_RegControl_Data{i,1}.ForwardX = Regcontrols.ForwardX;
        dss_RegControl_Data{i,1}.ReverseR = Regcontrols.ReverseR;
        dss_RegControl_Data{i,1}.ReverseX = Regcontrols.ReverseX;  
        dss_RegControl_Data{i,1}.IsReversible = Regcontrols.IsReversible;  
        dss_RegControl_Data{i,1}.IsInverseTime = Regcontrols.IsInverseTime;  
        dss_RegControl_Data{i,1}.Delay = Regcontrols.Delay;  
        dss_RegControl_Data{i,1}.TapDelay = Regcontrols.TapDelay;  
        dss_RegControl_Data{i,1}.MaxTapChange = Regcontrols.MaxTapChange;  
        dss_RegControl_Data{i,1}.VoltageLimit = Regcontrols.VoltageLimit; 
        dss_RegControl_Data{i,1}.ForwardBand = Regcontrols.ForwardBand; 
        dss_RegControl_Data{i,1}.ForwardVreg = Regcontrols.ForwardVreg; 
        dss_RegControl_Data{i,1}.ReverseBand = Regcontrols.ReverseBand; 
        dss_RegControl_Data{i,1}.ReverseVreg = Regcontrols.ReverseVreg; 
        dss_RegControl_Data{i,1}.Count = Regcontrols.Count; 
        dss_RegControl_Data{i,1}.TapNumber = Regcontrols.TapNumber; 
        
        Regcontrols.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_RegControl_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_RegControl_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_RegControl_Data{i,1}.n_regcontrol = n_regcontrol;
    end
    
    
end

