function dss_Bus_Data = f_get_bus(DSSCircuit)

    Buses = DSSCircuit.ActiveBus;
    
    n_bus = DSSCircuit.NumBuses;
    if n_bus == 0
        dss_Bus_Data = {};
        return
    else
        names = DSSCircuit.AllBusNames; % will go through all transformers
    end

    for i = 1 : n_bus
        got = DSSCircuit.SetActiveBus(names{i});
%         dss_Bus_Data{i,1} = Buses.get;
        dss_Bus_Data{i,1}.Name = Buses.Name;
        dss_Bus_Data{i,1}.NumNodes = Buses.NumNodes;
        dss_Bus_Data{i,1}.Nodes = Buses.Nodes;
        dss_Bus_Data{i,1}.kVBase = Buses.kVBase;
        dss_Bus_Data{i,1}.Coorddefined = Buses.Coorddefined;
        dss_Bus_Data{i,1}.x = Buses.x;
        dss_Bus_Data{i,1}.y = Buses.y;
        dss_Bus_Data{i,1}.n_bus = n_bus;
    end


end