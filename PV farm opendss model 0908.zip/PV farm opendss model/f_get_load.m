function dss_Load_Data = get_load(DSSCircuit)

    Loads = DSSCircuit.Loads;
    
    iL = Loads.First;
    
    if iL == 0
        dss_Load_Data = {};
        return
    else
        names = Loads.AllNames;
    end
    
    n_load = length(names);
    for i = 1 : n_load
        Loads.Name = names{i}; % not assign value, but to set the "pointer" position
        dss_Load_Data{i,1}.Name = Loads.Name;
        dss_Load_Data{i,1}.kV = Loads.kV;
        dss_Load_Data{i,1}.kW = Loads.kW;
        dss_Load_Data{i,1}.kvar = Loads.kvar;
        

        Loads.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_Load_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_Load_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_Load_Data{i,1}.n_load = n_load;
    end

end

