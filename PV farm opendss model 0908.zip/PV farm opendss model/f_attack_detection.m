


Current_irridiance = Irridiance(ceil(time + 0.1));

[DSSStartOK, DSSObj, DSSText] = DSSStartup;
DSSCircuit = DSSObj.ActiveCircuit;
DSSSolution = DSSCircuit.Solution;

out_PVVIPQ = [];
PVNames = DSSCircuit.PVSystems.AllNames;
for i = 1 : DSSCircuit.PVSystems.Count
    DSSCircuit.SetActiveElement(['PVSystem.', PVNames{i}]); %%%%%%%%%%%%%
    DSSCircuit.PVSystems.Name = PVNames{i}; %%%%%%%%%%%%%
    three_phase_value = f_phase_alignment(DSSCircuit,'pv');
    out_PVVIPQ = [out_PVVIPQ; three_phase_value];    
end

detection_status = 0;
for i = 1 : n_pv
    threshold = 0.001;
    % V
    mismatch = max(abs(out_PVVIPQ(i, 1:3) - data_pv_V(i,:))./abs(out_PVVIPQ(i, 1:3)));
    if mismatch > threshold
        detection_status = 1;
    end
    % PQ
    mismatch = max(abs(out_PVVIPQ(i, 7:9) - data_pv_PQ(i,:))./abs(out_PVVIPQ(i, 7:9) + 0.01));  % 0.01 to avoid '0' case
    if mismatch > threshold
        detection_status = 1;
    end
end


% for i = 1 : n_pv
%     PV_PQ = sum(data_pv_PQ(i, 7:9));
%     PV_PQ_theory = Current_irridiance * System_config.PV{i}.kVArated * System_config.PV{i}.
%     threshold = 0.1;
% %     if PV_PQ - 
%     
% end