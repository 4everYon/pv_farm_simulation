function dss_PVSystems_Data = f_get_pv(DSSCircuit)

    PV = DSSCircuit.PVSystems;
    
    iL = PV.First;
    
    if iL == 0
        dss_PVSystems_Data = {};
        return
    else
        names = PV.AllNames;
    end
    
    n_pv = length(names);
    for i = 1 : n_pv
        PV.Name = names{i}; % not assign value, but to set the "pointer" position
        dss_PVSystems_Data{i,1}.Name = PV.Name;
        dss_PVSystems_Data{i,1}.Count = PV.Count;
        dss_PVSystems_Data{i,1}.idx = PV.idx;
        dss_PVSystems_Data{i,1}.Irradiance = PV.Irradiance;
        dss_PVSystems_Data{i,1}.kvar = PV.kvar;
        dss_PVSystems_Data{i,1}.kVArated = PV.kVArated;
        dss_PVSystems_Data{i,1}.kW = PV.kW;
        
        
        PV.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_PVSystems_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_PVSystems_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_PVSystems_Data{i,1}.n_pv = n_pv;
    end
    

end

