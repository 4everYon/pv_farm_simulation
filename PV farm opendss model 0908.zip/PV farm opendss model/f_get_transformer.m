function dss_Transformer_Data = get_transformer(DSSCircuit)

    
    Transformers = DSSCircuit.Transformers;
    
    iXm = Transformers.First; % two purposes: 1) reset pointer to be the first transformer, 
                              % 2) set iXm-th transformer as the active element (i.e., act_ele)
    if iXm == 0
        dss_Transformer_Data = {};
        return
    else
        names = Transformers.AllNames; % will go through all transformers
    end
    
    n_transformer = length(names);
    for i = 1 : n_transformer
        Transformers.Name = names{i}; % not assign value, but to set the "pointer" position
        dss_Transformer_Data{i,1}.Name = Transformers.Name;
        dss_Transformer_Data{i,1}.kV = Transformers.kV;
        dss_Transformer_Data{i,1}.kva = Transformers.kva;
        dss_Transformer_Data{i,1}.R = Transformers.R;
        dss_Transformer_Data{i,1}.Xhl = Transformers.Xhl;
        dss_Transformer_Data{i,1}.NumWindings = Transformers.NumWindings;
        dss_Transformer_Data{i,1}.AllNames = Transformers.AllNames;
               
        Transformers.Name = names{i}; % not assign value, but to set the "pointer" position
        act_ele = DSSCircuit.ActiveCktElement;
        dss_Transformer_Data{i,1}.NumPhases = act_ele.NumPhases;
        dss_Transformer_Data{i,1}.BusNames = act_ele.BusNames;   
        dss_Transformer_Data{i,1}.n_transformer = n_transformer;
    end

end

