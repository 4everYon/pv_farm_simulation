% Identify Target Actor and Device
AffectedMeasurements = split(Scenario.AffectedMeasurement, ',');

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Inverter' 
                %%
                attacked_inv = Attack_config.FieldDevice.Inverter_victim_idx;
                
                
                switch Scenario.AttackType{1}
                    case 'DoS'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(attacked_inv, :) = data_pv_I(attacked_inv, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'PQ') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(attacked_inv, :) = data_pv_PQ(attacked_inv, :) * NaN;
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(attacked_inv, :) = data_pv_V(attacked_inv, :) * NaN;
                        end
                    case 'MITM'  
                        if sum( ismember(AffectedMeasurements, 'I') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_I(attacked_inv, :) = data_pv_I(attacked_inv, :) * (0.9 + rand()/10);
                        end
                        if sum( ismember(AffectedMeasurements, 'PQ') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_PQ(attacked_inv, :) = data_pv_PQ(attacked_inv, :) * (0.9 + rand()/10);
                        end
                        if sum( ismember(AffectedMeasurements, 'V') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            data_pv_V(attacked_inv, :) = data_pv_V(attacked_inv, :) * (0.9 + rand()/10);
                        end
                end
            
                
        end
        
        
end

