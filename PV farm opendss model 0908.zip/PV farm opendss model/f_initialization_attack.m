if exist('batch_mode','var')
else
    batch_mode = 0;
end

%% if in batch mode, Attack_config should have been defined with this field
if batch_mode == 1
    %%
    load('batch_para.mat');
    Attack_config.Scenarios = Scenarios;
    Attack_config.ScenarioIndex = scenario_idx;
    Scenario = Attack_config.Scenarios(scenario_idx,:);
    Penetration = Scenario.PenetrationPercentage/100;

    switch Scenario.TargetActor{1}
        case 'FieldDevice'
            switch Scenario.TargetDevice{1}
                case 'Inverter' 
                    n_pv = System_config.PV{1,1}.n_pv;
                    Attack_config.FieldDevice.Inverter_victim_idx = sort( randperm(n_pv, ceil(Penetration*n_pv)) );

            end
            
    end



else
    %%
    scenario_idx = 1; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%
    Attack_config.Scenarios = readtable([ pwd , '\xlsx_data\attack_data_batch.xlsx' ]);
    Attack_config.ScenarioIndex = scenario_idx;
    
    Scenario = Attack_config.Scenarios(scenario_idx,:);
    Penetration = Scenario.PenetrationPercentage/100;

    switch Scenario.TargetActor{1}
        case 'FieldDevice'
            switch Scenario.TargetDevice{1}
                case 'Inverter' 
                    n_pv = System_config.PV{1,1}.n_pv;
                    Attack_config.FieldDevice.Inverter_victim_idx = sort( randperm(n_pv, ceil(Penetration*n_pv)) );
                    
                case 'Controller' 
                    n_pv = System_config.PV{1,1}.n_pv;
                    Attack_config.FieldDevice.Inverter_victim_idx = sort( randperm(n_pv, ceil(Penetration*n_pv)) );                   

            end
            
            
    end
    
end
