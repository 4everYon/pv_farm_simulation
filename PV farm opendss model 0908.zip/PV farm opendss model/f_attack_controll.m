% Identify Target Actor and Device
AffectedMeasurements = split(Scenario.AffectedMeasurement, ',');

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Controller' 
                %%
                attacked_inv = Attack_config.FieldDevice.Inverter_victim_idx;
                
                
                switch Scenario.AttackType{1}
                    case 'MITM'  
                        if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(attacked_inv, 1) = 1;
                            output(attacked_inv, 2) = rand(length(attacked_inv),1);
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(attacked_inv, 3) = 1;
                            output(attacked_inv, 4) = 30*rand(length(attacked_inv),1);
                        end

                end
            
                
        end
        
        
end

