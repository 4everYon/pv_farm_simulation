function Sim_Attack_Control(block)
    setup(block);

function setup(block)

    % Register the number of ports.
    block.NumInputPorts  = 1;
    block.NumOutputPorts = 2;

    % Set up the port properties to be inherited or dynamic.
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;

    DSS_port_config = block.DialogPrm(1).Data;
    System_config   = block.DialogPrm(2).Data;
    
    block.InputPort(1).Dimensions     = 1;
    block.InputPort(1).Complexity     = 'real';
    block.InputPort(1).SamplingMode   = 'Sample';
    
    n_pv = System_config.PV{1,1}.n_pv;
    
    block.OutputPort(1).Dimensions     = [n_pv 4]; %%% [flag_PF, PF, flag_kvar, kvar]
    block.OutputPort(1).Complexity     = 'real';
    block.OutputPort(1).SamplingMode   = 'Sample';
    
    block.OutputPort(2).Dimensions     = 1;
    block.OutputPort(2).Complexity     = 'real'; 
    block.OutputPort(2).SamplingMode   = 'Sample';
    
    % Register the parameters.
    block.NumDialogPrms     = 4;
    %   block.DialogPrmsTunable = {'Tunable','Nontunable','SimOnlyTunable'};

    block.SampleTimes = [-1 0];
    block.SetAccelRunOnTLC(false);
    block.SimStateCompliance = 'DefaultSimState';

    block.RegBlockMethod('SetInputPortSamplingMode', @SetInpPortFrameData);
    block.RegBlockMethod('Outputs', @Outputs);
 
function SetInpPortFrameData(block, idx, fd)
    block.InputPort(idx).SamplingMode = fd;
    block.OutputPort(idx).SamplingMode = fd;

function SetInputDimsMode(block, port, dm)
    block.InputPort(port).DimensionsMode = dm;
    block.OutputPort(port).DimensionsMode = dm;

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Outputs(block)
    attack_enable = block.InputPort(1).Data;
    System_config = block.DialogPrm(2).Data;
    SCADA_config    = block.DialogPrm(3).Data;
    Attack_config = block.DialogPrm(4).Data;
        
    if attack_enable == 1
        n_pv = System_config.PV{1,1}.n_pv;
        output = zeros(n_pv,4);

        %% batch mode
        if isfield(Attack_config, 'ScenarioIndex')
            idx = Attack_config.ScenarioIndex;
        else
            idx = 1;
            disp('ScenarioIndex not found, set idx to 1');
        end
        Scenario = Attack_config.Scenarios(idx,:);
        StartTime = Scenario.StartTime;
        EndTime = Scenario.EndTime;
        attack_status = 0;
        if block.CurrentTime >= StartTime && block.CurrentTime < EndTime
            %%
            f_attack_controll;
            attack_status = 1;
        end

        block.OutputPort(1).Data = output;
        block.OutputPort(2).Data = attack_status;
        
    elseif attack_enable == 0
        n_pv = System_config.PV{1,1}.n_pv;
        output = zeros(n_pv,4);
        block.OutputPort(1).Data = output;
        block.OutputPort(2).Data = 0;
    end
  
    
  
