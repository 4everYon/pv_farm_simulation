%% Ref: Diagram of 2.4 MW solar farm at Lymington, Hampshire
% https://westsolentsolar.coop/wp-content/uploads/2015/01/Solar-farm-diagramNov17-2014.pdf

clear

file_folder_path = 'C:\Users\bo.chen\OneDrive - Argonne National Laboratory\Code\pv_secure\PV farm opendss model';
PVfarm_file    = 'PVfarm.xlsx';
dss_file = 'Master.dss';

% check how many sheets in this xlsx file
cd(file_folder_path);
delete(dss_file);
[~,SheetNames] = xlsfinfo(PVfarm_file);
nSheets = length(SheetNames);

% import xlsx file
for ii = 1 : nSheets
    SheetName = SheetNames{ii};
%     if strcmp(SheetName, 'General')
%         % 'General' sheet needs to have 1st row ignored
%         T = readtable(PVfarm_file, 'Sheet', SheetName, 'Range','A2:B4');
%     else
    T = readtable(PVfarm_file, 'Sheet', SheetName);
%     end
    Name = SheetName(find( isstrprop(SheetName,'alpha') + isstrprop(SheetName,'digit') == 1) );
    ToDo = strcat('DATA.',Name,'=T;');
    eval(ToDo);
end

%% Check list for OpenDSS Format
% 1. Sources
% 2. Transformes
% 3. Distribution boards
% 4. Inverters
% 5. Lines and linecode
% 7. PV systems
% 8. XYcurve Loadshape and Tshape
% 9. Solver configuration

%% process imported data and organize into 'System'
%% General
System.Name = DATA.General.Properties.VariableNames{2};
System.frequency = DATA.General(1,2).Variables;
System.Powerbase = DATA.General(2,2).Variables;


%% V source
nVsource = size(DATA.Substation,1);
for ii = 1 : nVsource
    System.Substation.ID{ii} = DATA.Substation.ID{ii};
    System.Substation.busA{ii} = DATA.Substation.busA{ii};
    System.Substation.busB{ii} = DATA.Substation.busB{ii};
    System.Substation.busC{ii} = DATA.Substation.busC{ii};
    System.Substation.baseKVpp(ii) = DATA.Substation.kV_ph_phRMS_(ii);
    System.Substation.baseKVpg(ii) =DATA.Substation.kV_ph_phRMS_(ii)/sqrt(3);
    System.Substation.Vpu(ii) = 1; 
end

%% Transformer 
% !!! Currently can only handle wye-wye connections
% Example: new transformer.reg1a phases=3 windings=2 buses=[sourcebus 150r] conns=[wye wye] ...
% kvs=[4.16 4.16] kvas=[5000 5000] XHL=.001 %LoadLoss=0.00001 ppm=0.0
nTrans = size(DATA.Transformer, 1);
for ii = 1 : nTrans
   System.Trans.ID{ii} = DATA.Transformer.ID{ii};
   System.Trans.nPhase(ii) = DATA.Transformer.NumberOfPhases(ii);
   if System.Trans.nPhase(ii) == 3
       System.Trans.Phases{ii} = '1.2.3'; % 1->A, 2->B, 3->C
   elseif System.Trans.nPhase(ii) == 1
       D = DATA.Transformer.W1Bus1{ii}(end); % ASSUME last letter represents phase
       switch D
           case 'A'
               PH = '1';
           case 'B'
               PH = '2';
           case 'C'
               PH = '3';
           otherwise
               disp('Error with reading transformer phase information/n');
       end
       System.Trans.Phases{ii} = PH;
   end
   System.Trans.nWinding(ii) = 2; % Looks like OPAL format can only support 2-winding transformer
   W1bus = DATA.Transformer.W1Bus1{ii}(1:end-2);
   W2bus = DATA.Transformer.W2Bus1{ii}(1:end-2);
   System.Trans.buses{ii} = {W1bus, W2bus}; % NOTE even Single C Phase trans will put bus IDs in W1Bus1 and W2Bus1
   W1conn = DATA.Transformer.W1Conn_Type{ii};
   W2conn = DATA.Transformer.W2Conn_Type{ii};
   System.Trans.conns{ii} = {W1conn, W2conn};
   W1kvs = DATA.Transformer.W1V_kV_(ii);
   W2kvs = DATA.Transformer.W2V_kV_(ii);
   System.Trans.kvs{ii} = [W1kvs, W2kvs];
   W1kvas = DATA.Transformer.W1S_base_kVA_(ii);
   W2kvas = DATA.Transformer.W2S_base_kVA_(ii);
   System.Trans.kvas{ii} = [W1kvas, W2kvas];
   System.Trans.XHL(ii) = DATA.Transformer.X_pu_(ii);
   System.Trans.W1Rpu(ii) = DATA.Transformer.W1R_pu_(ii);
   System.Trans.W2Rpu(ii) = DATA.Transformer.W2R_pu_(ii);
end



%% Distribution Board
DBInfo = DATA.DistributionBoard;
nDB = size(DBInfo,1);
for ii = 1 : nDB
    System.DistributionBoard.ID{ii} = DBInfo.ID{ii};
    System.DistributionBoard.baseKV(ii) = DBInfo.Voltage_kV_(ii);
    System.DistributionBoard.nPhases(ii) = DBInfo.Phases(ii);
    System.DistributionBoard.nInverter(ii) = DBInfo.n_inverter(ii);
    System.DistributionBoard.TransformerID{ii} = DBInfo.Transformer_ID{ii};
    System.DistributionBoard.DB2Tran_length(ii) = DBInfo.Length_mile_(ii);
    System.DistributionBoard.DB2Tran_linecode{ii} = DBInfo.Linecode_ID{ii};
end


%% Inverter
InvInfo = DATA.Inverter;
nInv = size(InvInfo,1);
for ii = 1 : nInv
    System.Inverter.ID{ii} = InvInfo.ID{ii};
    System.Inverter.Capacity(ii) = InvInfo.Capacity_kva_(ii);
    System.Inverter.nPhases(ii) = InvInfo.Phases(ii);
    System.Inverter.baseKV(ii) = InvInfo.kV_ph_phRMS_(ii);
    System.Inverter.nString(ii) = InvInfo.n_string(ii);
    System.Inverter.nModule(ii) = InvInfo.n_module(ii);
    System.Inverter.nModule_per_string(ii) = InvInfo.n_module_per_string(ii);
    System.Inverter.PTcurve{ii} = InvInfo.PT_curve{ii};
    System.Inverter.Effcurve{ii} = InvInfo.Eff_curve{ii};
    System.Inverter.Irridance{ii} = InvInfo.Irradiance{ii};
    System.Inverter.Temperature{ii} = InvInfo.Temperature{ii};
    System.Inverter.DB_ID{ii} = InvInfo.DB_ID{ii};
    System.Inverter.Inv2DB_length_mile(ii) = InvInfo.Length_mile_(ii);
    System.Inverter.Inv2DB_linecode{ii} = InvInfo.Linecode_ID{ii};
end



%% LineCode  
LineCodeInfo = DATA.Linecode;  
[x,y]=find(isnan(LineCodeInfo{:,4:end})==1);
for ii = 1 : length(x)
    LineCodeInfo{x(ii),y(ii)} = 0;
end
nLineCode = size(LineCodeInfo,1);
for ii = 1 : nLineCode
    System.LineCode.ID{ii} = LineCodeInfo.ID{ii};
    
    Rmatrix = LineCodeInfo{ii,4:end}([1,3,5,7,9,11]); %r11/r21/r22/r31/r32/r33
    Xmatrix = LineCodeInfo{ii,4:end}([2,4,6,8,10,12]);%x11/x21/x22/x31/x32/x33
    Bmatrix = LineCodeInfo{ii,4:end}(13:18);        %b11/b21/b22/b31/b32/b33
    Cmatrix = Bmatrix/(2*pi*System.frequency); % B = wC = 2*pi*f*C, B is in Simens (S), C is in Farads (F)
    
    System.LineCode.Rmatrix{ii} = Rmatrix;
    System.LineCode.Xmatrix{ii} = Xmatrix;
    System.LineCode.Cmatrix{ii} = Cmatrix;
    System.LineCode.nPhases(ii) = LineCodeInfo.Phases(ii);
end


%% Line = Inverter to DB & DB to Trans
% More lines can be added to speadsheet in the future
nLine = 0;
for ii = 1 : nDB
    nLine = nLine + 1;
    System.Line.ID{nLine} = [System.DistributionBoard.ID{ii},'_to_', System.DistributionBoard.TransformerID{ii}];
    System.Line.FromBus{nLine} = System.DistributionBoard.ID{ii};
    TransLoc = find( strcmp(System.DistributionBoard.TransformerID{ii}, System.Trans.ID)==1 );
    System.Line.ToBus{nLine} = System.Trans.buses{TransLoc}{2};
    System.Line.Length(nLine) = System.DistributionBoard.DB2Tran_length(ii);
    System.Line.LineCodeID{nLine} = System.DistributionBoard.DB2Tran_linecode{ii};
    LineCodeLoc = find( strcmp(System.DistributionBoard.DB2Tran_linecode{ii}, System.LineCode.ID)==1 );
    System.Line.nPhases(nLine) = System.LineCode.nPhases(LineCodeLoc);
    if System.Line.nPhases(nLine) == 3
        System.Line.Phases{nLine} = '1.2.3';
    else
        disp('Single phase lines are not supported in current version.');
    end
end
for ii = 1 : nInv
    nLine = nLine + 1;
    System.Line.ID{nLine} = [System.Inverter.ID{ii},'_to_', System.Inverter.DB_ID{ii}];
    System.Line.FromBus{nLine} = System.Inverter.ID{ii};
    System.Line.ToBus{nLine} = System.Inverter.DB_ID{ii};
    System.Line.Length(nLine) = System.Inverter.Inv2DB_length_mile(ii);
    System.Line.LineCodeID{nLine} = System.Inverter.Inv2DB_linecode{ii};
    LineCodeLoc = find( strcmp(System.Inverter.Inv2DB_linecode{ii}, System.LineCode.ID)==1 );
    System.Line.nPhases(nLine) = System.LineCode.nPhases(LineCodeLoc);
    if System.Line.nPhases(nLine) == 3
        System.Line.Phases{nLine} = '1.2.3';
    else
        disp('Single phase lines are not supported in current version.');
    end
end

%% XYcurve
% P-T curve
nPTcurve = 1; % assume only have 1 curve
System.PTcurve.ID = {'PTcurve_1'};
System.PTcurve.npoints = size(DATA.PTcurve1.xarray_temperature_,1);
System.PTcurve.xarray = DATA.PTcurve1.xarray_temperature_;
System.PTcurve.yarray = DATA.PTcurve1.yarray_Pmpp_;
% Efficiency curve
nEffcurve = 1; % assume only have 1 curve
System.Effcurve.ID = {'Effcurve_1'};
System.Effcurve.npoints = size(DATA.Effcurve1.xarray_puPower_,1);
System.Effcurve.xarray = DATA.Effcurve1.xarray_puPower_;
System.Effcurve.yarray = DATA.Effcurve1.yarray_efficiency_;

%% Loadshape for Solar Irrdiance 
% read from Solar.csv
[Irradiance_list,IA_solar,IC_solar] = unique(System.Inverter.Irridance);
nIrrad = size(Irradiance_list,1);
for ii = 1 : nIrrad
    System.Irradiance.ID{ii} = Irradiance_list{ii}(1:end-4); % remove ".csv" from "Solar.csv"
    T = readtable(Irradiance_list{ii});
    System.Irradiance.npoints(ii) = size(T,1);
    System.Irradiance.interval(ii) = T{2,1} - T{1,1}; % assume 1st column is in hour
    System.Irradiance.mult{ii} = T{:,2};
end

%% Tshape (Temperature) 
% read from Temp.csv
[Temp_list,IA_temp,IC_temp] = unique(System.Inverter.Temperature);
nTemp = size(Temp_list,1);
for ii = 1 : nTemp
    System.Temperature.ID{ii} = Temp_list{ii}(1:end-4);
    T = readtable(Temp_list{ii});
    System.Temperature.npoints(ii) = size(T,1);
    System.Temperature.interval(ii) = T{2,1} - T{1,1}; % assume 1st column is in hour
    System.Temperature.temp{ii} = T{:,2};
end


%% Bus 
% This is to get base voltage levels
BusInfo = DATA.Bus;
nType = size(BusInfo,1);
for ii = 1 : nType
    System.Bus.Type{ii} = BusInfo.Type{ii};
    System.Bus.baseKV(ii) = BusInfo.kV_ph_phRMS_(ii);
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Write into OpenDSS file
fileID = fopen(dss_file,'w');

% Start with 'Clear'
fprintf(fileID,'Clear');
fprintf(fileID,'\n\n\n');

% Define new circuit, ASSUME Vsource(1) is the substation bus. 
TEXT = ['New object=circuit.',System.Name,' ','basekv=', num2str(System.Substation.baseKVpp(1)),' ',...
        'Bus1=',System.Substation.ID{1},' ','pu=', num2str(System.Substation.Vpu(1)),' ','r1=0 0.0001 0 0.0001','\n\n'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');

% Define transformers
for ii = 1 : nTrans
    TEXT = ['New transformer.', System.Trans.ID{ii},' ', ...
            'phases=', num2str(System.Trans.nPhase(ii)), ' ', ...
            'windings=', num2str(System.Trans.nWinding(ii)), ' ', ...
            'buses=[', System.Trans.buses{ii}{1},'.',System.Trans.Phases{ii},' ',...
                       System.Trans.buses{ii}{2},'.',System.Trans.Phases{ii},']', ' ',...
            'conns=[', System.Trans.conns{ii}{1},' ',System.Trans.conns{ii}{2},']', ' ', ...
            'kvs=[', num2str(System.Trans.kvs{ii}(1)),' ',num2str(System.Trans.kvs{ii}(2)),']',' ',...
            'kvas=[', num2str(System.Trans.kvas{ii}(1)),' ',num2str(System.Trans.kvas{ii}(2)),']',' ',...
            'XHL=', num2str(System.Trans.XHL(ii)), ' ',...
            'ppm=0.0','\n' ]; % LoadLoss and ppm are default
    fprintf(fileID,TEXT);    
end
fprintf(fileID,'\n\n\n');

% Define linecode
for ii = 1 : nLineCode
    if System.LineCode.nPhases(ii) == 1
        RTEXT = ['(',num2str(System.LineCode.Rmatrix{ii}(1)),')'];
        XTEXT = ['(',num2str(System.LineCode.Xmatrix{ii}(1)),')'];
        CTEXT = ['(',num2str(System.LineCode.Cmatrix{ii}(1)),')'];
    elseif System.LineCode.nPhases(ii) == 2
        RTEXT = ['(',num2str(System.LineCode.Rmatrix{ii}(1)),' | ',num2str(System.LineCode.Rmatrix{ii}(2)),' ',num2str(System.LineCode.Rmatrix{ii}(3)),' ',')'];
        XTEXT = ['(',num2str(System.LineCode.Xmatrix{ii}(1)),' | ',num2str(System.LineCode.Xmatrix{ii}(2)),' ',num2str(System.LineCode.Xmatrix{ii}(3)),' ',')'];
        CTEXT = ['(',num2str(System.LineCode.Cmatrix{ii}(1)),' | ',num2str(System.LineCode.Cmatrix{ii}(2)),' ',num2str(System.LineCode.Cmatrix{ii}(3)),' ',')'];
    elseif System.LineCode.nPhases(ii) == 3
        RTEXT = ['(',num2str(System.LineCode.Rmatrix{ii}(1)),' | ',num2str(System.LineCode.Rmatrix{ii}(2)),' ',num2str(System.LineCode.Rmatrix{ii}(3)),' | ',...
                    num2str(System.LineCode.Rmatrix{ii}(4)),' ',num2str(System.LineCode.Rmatrix{ii}(5)),' ',num2str(System.LineCode.Rmatrix{ii}(6)),')'];
        XTEXT = ['(',num2str(System.LineCode.Xmatrix{ii}(1)),' | ',num2str(System.LineCode.Xmatrix{ii}(2)),' ',num2str(System.LineCode.Xmatrix{ii}(3)),' | ',...
                    num2str(System.LineCode.Xmatrix{ii}(4)),' ',num2str(System.LineCode.Xmatrix{ii}(5)),' ',num2str(System.LineCode.Xmatrix{ii}(6)),')'];
        CTEXT = ['(',num2str(System.LineCode.Cmatrix{ii}(1)),' | ',num2str(System.LineCode.Cmatrix{ii}(2)),' ',num2str(System.LineCode.Cmatrix{ii}(3)),' | ',...
                    num2str(System.LineCode.Cmatrix{ii}(4)),' ',num2str(System.LineCode.Cmatrix{ii}(5)),' ',num2str(System.LineCode.Cmatrix{ii}(6)),')'];  
    end
    TEXT = ['New linecode.',num2str(System.LineCode.ID{ii}),' ',...
            'nphases=',num2str(System.LineCode.nPhases(ii)),' ',...
            'BaseFreq=',num2str(System.frequency),' '...
            'rmatrix=', RTEXT,' ',...
            'xmatrix=', XTEXT,' ',...
            'cmatrix=', CTEXT,' ',...
            '\n'];
    fprintf(fileID,TEXT);     
end
fprintf(fileID,'\n\n\n');

% Define lines
for ii = 1 : nLine
    TEXT = ['New Line.',System.Line.ID{ii},' ',...
            'Phases=',num2str(System.Line.nPhases(ii)),' ',...
            'Bus1=',System.Line.FromBus{ii},'.',System.Line.Phases{ii},' ',...
            'Bus2=',System.Line.ToBus{ii},'.',System.Line.Phases{ii},' ',...
            'LineCode=',num2str(System.Line.LineCodeID{ii}),' ',...
            'Length=',num2str(System.Line.Length(ii)),' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');


% Define XYcurve
for ii = 1 : nPTcurve
    TEXT = ['New XYCurve.',System.PTcurve.ID{ii},' ',...
            'npts=',num2str(System.PTcurve.npoints(ii)),' ',...
            'xarray=[',num2str(System.PTcurve.xarray'),']',' ',...
            'yarray=[',num2str(System.PTcurve.yarray'),']',' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');
for ii = 1 : nEffcurve
    TEXT = ['New XYCurve.',System.Effcurve.ID{ii},' ',...
            'npts=',num2str(System.Effcurve.npoints(ii)),' ',...
            'xarray=[',num2str(System.Effcurve.xarray'),']',' ',...
            'yarray=[',num2str(System.Effcurve.yarray'),']',' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');

% Define loadshape
for ii = 1 : nIrrad
    TEXT = ['New Loadshape.',System.Irradiance.ID{ii},' ',...
            'npts=',num2str(System.Irradiance.npoints(ii)),' ',...
            'interval=',num2str(System.Irradiance.interval(ii)),' ',...
            'mult=[',num2str(System.Irradiance.mult{ii}'),']',' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');


% Define Temperature Tshape
for ii = 1 : nTemp
    TEXT = ['New Tshape.',System.Temperature.ID{ii},' ',...
            'npts=',num2str(System.Temperature.npoints(ii)),' ',...
            'interval=',num2str(System.Temperature.interval(ii)),' ',...
            'temp=[',num2str(System.Temperature.temp{ii}'),']',' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');


% Define Inverters (PV systems)
for ii = 1 : nInv
    TEXT = ['New PVSystem.',System.Inverter.ID{ii},' ',...
            'phases=',num2str(System.Inverter.nPhases(ii)),' ',...
            'bus1=',System.Inverter.ID{ii},' ',...
            'kV=',num2str(System.Inverter.baseKV(ii)),' ',...
            'kVA=',num2str(System.Inverter.Capacity(ii)),' ',...
            'irrad=0.8',' ',...
            'Pmpp=',num2str(System.Inverter.Capacity(ii)),' ',...
            'temperature=25',' ',...
            'PF=1',' ',...
            'effcurve=Effcurve_1',' ',...
            'P-TCurve=PTcurve_1',' ',...
            'duty=',System.Irradiance.ID{IC_solar(ii)},' ',...
            'Tduty=',System.Temperature.ID{IC_temp(ii)},' ',...
            '\n'];
    fprintf(fileID,TEXT);
end
fprintf(fileID,'\n\n\n');


% Calculate voltage bases
TEXT = ['Set VoltageBases=[',num2str(unique(System.Bus.baseKV)),']','\n',...
        'CalcVoltageBases',' ',...
        '\n'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');


% Configure mode
TEXT = ['Set mode=OFF',' ',...
        '\n'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');
% TEXT = ['Set mode=duty',' ',...
%         'stepsize = ',num2str(System.Irradiance.interval),'h',' ',... %%%%%% 
%         'number = ',num2str(System.Irradiance.npoints),' ',...  %%%%%%%%%%%
%         '\n'];
% fprintf(fileID,TEXT);
% fprintf(fileID,'\n\n\n');

%% Add monitors
TEXT = ['new monitor.m1 PVSystem.Inv_64 1'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');



%% Configure solver
TEXT = ['solve','\n',...
        '\n'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');


%% Export monitors
TEXT = ['Plot monitor object= m1 channels=[1,3,5]'];
fprintf(fileID,TEXT);
fprintf(fileID,'\n\n\n');


fclose(fileID);



% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Need to put the generated Master.dss under a path without any special characters
system_folder_path = 'C:\test\PVfarm';
master_dss_file    = 'Master.dss';


% execute DSSStartup.m
[DSSStartOK, DSSObj, DSSText] = DSSStartup;

% get system configuration data from OpenDSS COM
if DSSStartOK

    DSSText.command = ['cd ', system_folder_path];
    DSSText.command = ['compile ', '(', master_dss_file, ')'];
    DSSCircuit = DSSObj.ActiveCircuit;
    DSSSolution = DSSCircuit.Solution;

%     nPV = DSSCircuit.PVSystems.Count;
%     for ii = 1 : nPV
%         DSSCircuit.PVSystems.Irradiance = 10;
%     end
    
end

