function Sim_Attack_SCADA(block)
    setup(block);

function setup(block)

    % Register the number of ports.
    block.NumInputPorts  = 7;
    block.NumOutputPorts = 7;

    % Set up the port properties to be inherited or dynamic.
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;

    DSS_port_config = block.DialogPrm(1).Data;
    
    block.InputPort(1).Dimensions     = DSS_port_config.port1dim;
    block.InputPort(2).Dimensions     = DSS_port_config.port2dim;
    block.InputPort(3).Dimensions     = DSS_port_config.port3dim;
    block.InputPort(4).Dimensions     = DSS_port_config.port4dim;
    block.InputPort(5).Dimensions     = DSS_port_config.port5dim;
    block.InputPort(6).Dimensions     = DSS_port_config.port6dim;
    block.InputPort(7).Dimensions     = 1;
    block.InputPort(7).Complexity     = 'real';
    
    block.OutputPort(1).Dimensions     = DSS_port_config.port1dim;
    block.OutputPort(2).Dimensions     = DSS_port_config.port2dim;
    block.OutputPort(3).Dimensions     = DSS_port_config.port3dim;
    block.OutputPort(4).Dimensions     = DSS_port_config.port4dim;
    block.OutputPort(5).Dimensions     = DSS_port_config.port5dim;
    block.OutputPort(6).Dimensions     = DSS_port_config.port6dim;
    block.OutputPort(7).Dimensions     = 1;
    block.OutputPort(7).Complexity     = 'real';
    
    % Register the parameters.
    block.NumDialogPrms     = 4;
    %   block.DialogPrmsTunable = {'Tunable','Nontunable','SimOnlyTunable'};

    block.SampleTimes = [-1 0];
    block.SetAccelRunOnTLC(false);
    block.SimStateCompliance = 'DefaultSimState';

    block.RegBlockMethod('SetInputPortSamplingMode', @SetInpPortFrameData);
    block.RegBlockMethod('Outputs', @Outputs);
 
function SetInpPortFrameData(block, idx, fd)
    block.InputPort(idx).SamplingMode = fd;
    block.OutputPort(idx).SamplingMode = fd;

function SetInputDimsMode(block, port, dm)
    block.InputPort(port).DimensionsMode = dm;
    block.OutputPort(port).DimensionsMode = dm;

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Outputs(block)

    attack_idx = block.InputPort(7).Data;
    System_config = block.DialogPrm(2).Data;
    SCADA_config    = block.DialogPrm(3).Data;
    Attack_config = block.DialogPrm(4).Data;
    
    if attack_idx > 0

        n_bus  = block.InputPort(1).Dimensions(1);
        n_line = block.InputPort(2).Dimensions(1);
        n_tran = block.InputPort(3).Dimensions(1);
        n_load = block.InputPort(4).Dimensions(1);
        n_cap  = block.InputPort(5).Dimensions(1);
        n_pv   = block.InputPort(6).Dimensions(1);

        data_node_V  = block.InputPort(1).Data;
        data_line_I  = block.InputPort(2).Data(:,1:6);
        data_line_PQ = block.InputPort(2).Data(:,7:12);
        data_tran_I  = block.InputPort(3).Data(:,1:6);
        data_tran_PQ = block.InputPort(3).Data(:,7:12);
        data_tran_Tap= block.InputPort(3).Data(:,13);
        data_load_I  = block.InputPort(4).Data(:,1:3);
        data_load_PQ = block.InputPort(4).Data(:,4:6);
        data_cap_I   = block.InputPort(5).Data(:,1:3);
        data_cap_PQ  = block.InputPort(5).Data(:,4:6);
        data_cap_St  = block.InputPort(5).Data(:,7);
        data_pv_V    = block.InputPort(6).Data(:,1:3);
        data_pv_I    = block.InputPort(6).Data(:,4:6);
        data_pv_PQ    = block.InputPort(6).Data(:,7:9);


    
        idx = attack_idx;
        Scenario = Attack_config.Scenarios(idx,:);
        
        StartTime = Scenario.StartTime;
        EndTime = Scenario.EndTime;
        Targets = 1:Scenario.NumberAffected;
        attack_status = 1;
        
        f_attack_inverter_scada;



        block.OutputPort(1).Data = data_node_V;
        block.OutputPort(2).Data = [data_line_I, data_line_PQ];
        block.OutputPort(3).Data = [data_tran_I, data_tran_PQ, data_tran_Tap];
        block.OutputPort(4).Data = [data_load_I, data_load_PQ];
        block.OutputPort(5).Data = [data_cap_I, data_cap_PQ, data_cap_St];
        block.OutputPort(6).Data = [data_pv_V, data_pv_I, data_pv_PQ];
        block.OutputPort(7).Data = attack_status;  %%%%%
        
    else
        
        block.OutputPort(1).Data = block.InputPort(1).Data;
        block.OutputPort(2).Data = block.InputPort(2).Data;
        block.OutputPort(3).Data = block.InputPort(3).Data;
        block.OutputPort(4).Data = block.InputPort(4).Data;
        block.OutputPort(5).Data = block.InputPort(5).Data;
        block.OutputPort(6).Data = block.InputPort(6).Data;
        block.OutputPort(7).Data = 0;
    end
  
    
  
