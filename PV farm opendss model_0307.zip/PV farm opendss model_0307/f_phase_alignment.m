function three_phase_value = f_phase_alignment(DSSCircuit, flag)
%%
    if strcmp(flag, 'bus')
        three_phase_value = zeros(1,3);
        phase_info = DSSCircuit.ActiveBus.Nodes;
        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
%                 % although the data is given by mag and angle, we can use
%                 % mag + 1i * ang to check data correctness...
%                 three_phase_value(j) = DSSCircuit.ActiveBus.VMagAngle(2*k-1)+ 1i* DSSCircuit.ActiveBus.VMagAngle(2*k);
                
                three_phase_value(j) = DSSCircuit.ActiveBus.VMagAngle(2*k-1) * exp( 1i* DSSCircuit.ActiveBus.VMagAngle(2*k)/180*pi  );
                
                k = k + 1;
            end
        end
    end
    
%%
    if strcmp(flag, 'line')
        three_phase_PQ = zeros(1,6);
        three_phase_C  = zeros(1,6);
        
%         from_bus = strsplit(DSSCircuit.Lines.Bus1,'.');
%         to_bus = strsplit(DSSCircuit.Lines.Bus2,'.');
%         
%         phase_info = [];
%         numP = DSSCircuit.Lines.Phases;
%         if  numP == 3
%             phase_info = [1, 2, 3];
%         else
%             for i = 2 : length(from_bus)
%                 p = str2num(from_bus{i});
%                 phase_info(p) = p;
%             end
%         end

        from_bus = strsplit(DSSCircuit.ActiveElement.BusNames{1},'.');
        if length(from_bus) == 1
            from_nodes = [1,2,3];
        else
            from_nodes = str2double(from_bus(2:end));
        end
        to_bus   = strsplit(DSSCircuit.ActiveElement.BusNames{2},'.');
        if length(to_bus) == 1
            to_nodes = [1,2,3];
        else
            to_nodes = str2double(to_bus(2:end));
        end
        
        phase_info = intersect(from_nodes, to_nodes);
        
        numP = length(phase_info);
        
        
        
        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
%                 % although the data is given by mag and angle, we can use
%                 % mag + 1i * ang to check data correctness...
%                 three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)+ 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k);
%                 three_phase_C(j+3)  = DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP - 1)+ 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP);

                three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)            .* exp(  1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k)/180*pi          );
                three_phase_C(j+3)  = DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP - 1) .* exp(  1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP)/180*pi );
                
                three_phase_PQ(j)   = DSSCircuit.ActiveElement.Powers(2*k-1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k);
                three_phase_PQ(j+3) = DSSCircuit.ActiveElement.Powers(2*k + 2*numP - 1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k + 2*numP);
                
                k = k + 1;
            end
        end
        three_phase_value = [ three_phase_C, three_phase_PQ ];
    end
    
%%
    if strcmp(flag, 'transformer')
        
        Tap = DSSCircuit.Transformers.Tap;
        
        three_phase_PQ = zeros(1,6);
        three_phase_C  = zeros(1,6);
        
        from_bus = strsplit(DSSCircuit.ActiveElement.BusNames{1},'.');
        if length(from_bus) == 1
            from_nodes = [1,2,3];
        else
            from_nodes = str2double(from_bus(2:end));
        end
        to_bus   = strsplit(DSSCircuit.ActiveElement.BusNames{2},'.');
        if length(to_bus) == 1
            to_nodes = [1,2,3];
        else
            to_nodes = str2double(to_bus(2:end));
        end
        
        phase_info = intersect(from_nodes, to_nodes);
        
        numP = length(phase_info);

        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
                % skip I1_4 for 3 phase transformer     
                
                three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)             * exp( 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k)/180*pi               );

                three_phase_C(j+3)  = DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP + 1)  * exp( 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k + 2*numP + 2)/180*pi  );
                
                three_phase_PQ(j)   = DSSCircuit.ActiveElement.Powers(2*k-1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k);
                three_phase_PQ(j+3) = DSSCircuit.ActiveElement.Powers(2*k + 2*numP + 1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k + 2*numP + 2);
                
                k = k + 1;
            end
        end
        three_phase_value = [ three_phase_C, three_phase_PQ, Tap ];
%         disp(Tap)
    end
    
%%
    if strcmp(flag, 'load')
        three_phase_PQ = zeros(1,3);
        three_phase_C  = zeros(1,3);
        
        bus = strsplit(DSSCircuit.ActiveElement.BusNames{1},'.');
        if length(bus) == 1
            phase_info = [1,2,3];
        else
            phase_info = str2double(bus(2:end));
        end
        
        numP = length(phase_info);

        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
                three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)  * exp( 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k)/180*pi  );
                three_phase_PQ(j)   = DSSCircuit.ActiveElement.Powers(2*k-1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k);

                k = k + 1;
            end
        end
        three_phase_value = [ three_phase_C, three_phase_PQ ];
    end
    
    
%%
    if strcmp(flag, 'capacitor')
        
        status = double( DSSCircuit.Capacitors.States );
        
        three_phase_PQ = zeros(1,3);
        three_phase_C  = zeros(1,3);

        bus = strsplit(DSSCircuit.ActiveElement.BusNames{1},'.');
        if length(bus) == 1
            phase_info = [1,2,3];
        else
            phase_info = str2double(bus(2:end));
        end
        
        numP = length(phase_info);

        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
                three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)  * exp( 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k)/180*pi  );
                three_phase_PQ(j)   = DSSCircuit.ActiveElement.Powers(2*k-1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k);

                k = k + 1;
            end
        end
        three_phase_value = [ three_phase_C, three_phase_PQ, status ];
    end
    

%% 
    if strcmp(flag, 'pv')
        bus = strsplit(DSSCircuit.ActiveElement.BusNames{1},'.');
        if length(bus) == 1
            phase_info = [1,2,3];
        else
            phase_info = str2double(bus(2:end));
        end
        
        three_phase_PQ = zeros(1,3);
        three_phase_C  = zeros(1,3);
        
        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)
                three_phase_C(j)    = DSSCircuit.ActiveElement.CurrentsMagAng(2*k-1)  * exp( 1i* DSSCircuit.ActiveElement.CurrentsMagAng(2*k)/180*pi  );
                three_phase_PQ(j)   = DSSCircuit.ActiveElement.Powers(2*k-1)+ 1i* DSSCircuit.ActiveElement.Powers(2*k);

                k = k + 1;
            end
        end
        
        three_phase_V = zeros(1,3);
        phase_info = DSSCircuit.ActiveBus.Nodes;
        k = 1;
        for j = 1 : 3
            if ismember(j, phase_info)           
                three_phase_V(j) = DSSCircuit.ActiveBus.VMagAngle(2*k-1) * exp( 1i* DSSCircuit.ActiveBus.VMagAngle(2*k)/180*pi  );
                k = k + 1;
            end
        end
        
        three_phase_value = [ three_phase_V, three_phase_C, three_phase_PQ ];
        
    end