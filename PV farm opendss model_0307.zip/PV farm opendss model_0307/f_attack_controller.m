% Identify Target Actor and Device

AffectedMeasurements = Scenario.AffectedMeasurement;

switch Scenario.TargetActor{1}
        
    case 'FieldDevice'

        switch Scenario.TargetDevice{1}
            case 'Controller' 

                switch Scenario.AttackType{1}
                    case 'MITM'  
                        if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(Targets, 1) = 1;
%                             output(Targets, 2) = rand(length(Targets),1);
                            output(Targets, 2) = (1-rem(block.CurrentTime,10)/10) * ones(length(Targets),1);
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(Targets, 3) = 1;
%                             output(Targets, 4) = 30*rand(length(Targets),1);
                            output(Targets, 4) = 30*(rem(block.CurrentTime,10)/10) * ones(length(Targets),1);
                        end
                        
                    case 'DoS'
                        if sum( ismember(AffectedMeasurements, 'PF') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(Targets, 1) = 1;
                            output(Targets, 2) = NaN * ones(length(Targets),1);
                        end
                        if sum( ismember(AffectedMeasurements, 'Q') ) > 0 % 'sum' is used for previous case with multiple scenarios
                            output(Targets, 3) = 1;
                            output(Targets, 4) = NaN * ones(length(Targets),1);
                        end
                        

                end
                
                
        end
          
end

